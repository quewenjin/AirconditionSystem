export default{
    content: '',
    chatText: [],
    searchChatText: [],
    sessionId: 'aaaa41aa012e46bfaa64671aadaa0aa7',
   
    userInfo: {
        userRoot: 1,
        userId: '12345678',
        userName: '王小虎',
        userAvatar: 'https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png',
    },
    teaClassInfo: {
        defaultName: '',
        defaultInfo: {},
        classList: []
    },
    teaList: [],//提交列表教师端
    stuClassInfo: {
        defaultName: '',
        defaultInfo: {},
        classList: []
    },
    stuHomeworkList: [],//学生端 作业提交详情
    homeworkList: [
        // {
        //     workId: "31865",
        //     workTitle: "装率当响开并价华现和受日。",
        //     workContext: "议至通儿大质通酸条什发铁国要知类改先。规收事铁造酸动率建具验段报。中反与管下大信已干相却较了节家。",
        //     shouldSubmit: 52,
        //     alreadySubmitted: 30,
        //     date: "2003-07-14",
        //     isShow: false,
        //     pictures: []
        // }
    ],
    memberList: [],
    tempMemberList: []
}
