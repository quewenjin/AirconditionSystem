<template>
    <div>
        <h2>任务通知</h2>
        <router-view/>
    </div>
</template>

<script>
export default {
    
}
</script>

<style scoped>

</style>