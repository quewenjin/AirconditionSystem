<template>
    <div>
        <h2>作业批改</h2>
        <router-view/>
    </div>
</template>

<script>
export default {

}
</script>

<style scoped>

</style>